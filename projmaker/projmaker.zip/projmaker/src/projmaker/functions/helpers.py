"""
Various useful functions.
"""
import shutil
import venv
from pathlib import Path


def remove_project_ifexists(path: str | Path):
    """
    If the directory exists, it deletes it recursively.
    """
    path = Path(path).resolve()
    if path.exists() and path.is_dir():
        shutil.rmtree(path)
        return True
    return False


def create_env(args):
    env = venv.EnvBuilder(clear=True,
                          with_pip=True,
                          upgrade_deps=True,
                          prompt=args.env_prompt)
    env.create(args.pth_env)
    print("  - the virtual environment has been created")


def save_dependencies(args):
    """
    The function writes the names of the modules to be installed to the
    file `requirements.txt`.
    """
    pass


def install_requirements(args):
    """
    The function installs dependencies from the file `requirements.txt`
    (python -m install -r requirements.txt)
    """
    pass
