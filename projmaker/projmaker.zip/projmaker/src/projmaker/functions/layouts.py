"""
Tworzy strukturę katalogów.

       myproj/
             |pyproject.toml
             |requirements.txt
             |README.md
             |src/
                 |
                 |myproj/
                        |__init__.py
                        |main.py
                        |modules/
                                |__init__.py

"""



def make_src_layout(args):
    # parents = True: create all missing parent folders
    args.pth_pkg.joinpath('modules').mkdir(parents=True, exist_ok=True)
    print("\n  The project directory src-layout has been created")

    # config / meta files
    for name in ("pyproject.toml", "README.md", "requirements.txt"):
        pth = args.pth_main_folder / name
        pth.touch(exist_ok=True)
        if name == "requirements.txt":
            pth.write_text("ipython\nbuild\nwheel\n")
        print(f"  - the `{name}` file has been created")

    # __init__.py
    (args.pth_pkg / '__init__.py').touch(exist_ok=True)
    (args.pth_pkg / 'modules' / '__init__.py').touch(exist_ok=True)
    print("  - the `__init__.py` files have been created")

    # main.py
    (args.pth_pkg / 'main.py').touch(exist_ok=True)
    print("  - the `main.py` file has been created")

