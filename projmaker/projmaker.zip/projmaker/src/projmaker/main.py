from pprint import pp

# local import
from projmaker.myparser import args_parser
from projmaker.functions import layouts as ly
from projmaker.functions import helpers as hlp


def main():
    args = args_parser.parsuj_argumenty()
    args = args_parser.args_processing(args)
    if args.verbose:
        pp(dict(sorted(vars(args).items())))

    # If the project directory exists - delete it recursively
    remove = hlp.remove_project_ifexists(args.pth_main_folder)
    if args.verbose and remove:
        print("The previously existing project directory:\n "
              f"`{args.proj_name}` has been removed!")

    # create folders
    ly.make_src_layout(args)

    # venv env
    hlp.create_env(args)



if __name__ == '__main__':
    main()
