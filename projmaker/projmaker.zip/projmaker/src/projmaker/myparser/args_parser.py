import argparse
import sys
import textwrap
from pathlib import Path

# local import

# --
# Help text line length
WIDTH = 90

description = textwrap.dedent("""
The script creates the project structure in the current directory:
- creates directories and subdirectories - src layout only!!!
- creates metadata files: pyproject.toml, README.md, requires.txt
- creates __init__.py files
- creates a virtual environment
               """)


def parsuj_argumenty():
    """
    What could be improved (what arguments to add):
    - if the project folder exists - user decision whether to delete it or not
    - project layout selection: src-layout, flat-layout
    - ability to specify a list of packages to install in the environment
    """
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter,
        description=description,
    )

    txt = textwrap.fill(("Str, project name: the name of the project's root "
                        "directory and therefore the name of the package "
                        "directory."), width=WIDTH)
    parser.add_argument("proj_name", help=txt, type=str)

    txt = textwrap.fill(("Str, the name of the CLI command to run the script. "
                        "If not specified, it will be the same as the project "
                        "name."), width=WIDTH)
    parser.add_argument("-c", "--cli_name", type=str, help=txt)

    txt = textwrap.fill(("Str. The name of the virtual environment directory. "
                        "Defaults is `env`."), width=WIDTH)
    parser.add_argument("-e", "--env_name",
                        help=txt,
                        type=str,
                        default='env')

    txt = textwrap.fill("Displays additional information.", width=WIDTH)
    parser.add_argument("-v", "--verbose", help=txt, action="store_true")

    return parser.parse_args()


def args_processing(args):
    root = Path.cwd().resolve()
    args.system = sys.platform

    # names
    args.proj_name = args.proj_name # .strip()

    if not args.cli_name:
        args.cli_name = args.proj_name

    args.env_name = args.env_name #.strip()
    args.env_prompt = args.proj_name

    # paths
    # main script folder
    args.pth_main_folder = root / args.proj_name

    # src folder
    args.pth_src = args.pth_main_folder / "src"

    # package folder
    args.pth_pkg = args.pth_src / "proj_name"

    # env folder
    args.pth_env = args.pth_main_folder / args.env_name
    return args
